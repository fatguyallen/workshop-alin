# production-ready-serverless-workshop-devexperience-demo

Demo project for the Production-Ready Serverless workshop at DevExperience